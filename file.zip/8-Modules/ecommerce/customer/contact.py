def contactBook():
    print("contact book is opened")
    pass
